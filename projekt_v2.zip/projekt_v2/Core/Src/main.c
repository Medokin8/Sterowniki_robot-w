/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include "lsm303c.h"
#include "l3gd20.h"
#include "stm32l476g_discovery.h"
#include "stm32l476g_discovery_gyroscope.h"
#include "stm32l476g_discovery_qspi.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
 QSPI_HandleTypeDef hqspi;

RTC_HandleTypeDef hrtc;

SPI_HandleTypeDef hspi2;

TIM_HandleTypeDef htim2;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
uint32_t start;
uint32_t stop;

float distanceMin = 0;
float distance1 = 0;
float distance2 = 0;
float distance3 = 0;
float distance4 = 0;

int remainingDelay = 300;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_RTC_Init(void);
static void MX_TIM2_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_SPI2_Init(void);
static void MX_QUADSPI_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
int __io_putchar(int ch)
{
    HAL_UART_Transmit(&huart2, (uint8_t*)&ch, 1, HAL_MAX_DELAY);
    return 1;
}


float min(float a, float b)
{
	if(a < b)
		return a;
	else
		return b;
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_RTC_Init();
  MX_TIM2_Init();
  MX_USART2_UART_Init();
  MX_SPI2_Init();
  MX_QUADSPI_Init();
  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  HAL_TIM_IC_Start(&htim2, TIM_CHANNEL_1);
  HAL_TIM_IC_Start(&htim2, TIM_CHANNEL_2);
  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_3);


  	  //RTC
  RTC_DateTypeDef sDate;
  RTC_TimeTypeDef sTime;
  RTC_DateTypeDef new_date = {0};
  RTC_TimeTypeDef new_time = {0};

  //ustawiamy godzine
  new_time.Hours = 16;
  new_time.Minutes = 17;
  new_time.Seconds = 0;
  HAL_RTC_SetTime(&hrtc, &new_time, RTC_FORMAT_BIN);
  //ustawiamy date
  new_date.WeekDay = RTC_WEEKDAY_TUESDAY;
  new_date.Month = RTC_MONTH_MAY;
  new_date.Date = 10;
  new_date.Year = 22;
  HAL_RTC_SetDate(&hrtc, &new_date, RTC_FORMAT_BIN);


  	  // akcelerometr
  	  // CTRL1=0x37, Normall mode, ODR=100Hz, BD=0(continous update), XYZ enable
  	  // CTRL4=0xE7, BW=50hz, Scale 4g, BW_SCALE_ODR=0(automatic), autoincrementing, I2C diable, SPI r&w
  uint16_t init1 = ( 0xE7 << 8 ) | ( 0x37 ); //0x2100 or 0x27 => 0x2127
  LSM303C_AccInit(init1);
  int16_t acc_data[3];
  float acc[3];


  	  // gyro:
  	  // CTRL1=0x3F, Normall mode, BD+ODDR=95Hz 25hz, XYZ enable,  skala 500, notacja LSB (little endians),
  	  // CTRL4=0x10, Continous update, LSB, Scale 500dps, 4wire
  uint8_t flag=0;
  if(BSP_GYRO_Init() == GYRO_OK)
	  flag=1;
  else
  	  flag=2;

  float gyro_data[3];
  float gyro[3]={0, 0, 0};

  BSP_GYRO_Reset();


  	  //QSPI_FLASH
uint8_t *qspi_word="hello";
uint8_t qspi_read[50];

float qspi_number=12.123;
//uint8_t qspi_number=123;
uint8_t qspi_buff[20];
//sprintf(qspi_buff,"%u",qspi_number);

gcvt(qspi_number, 20, qspi_buff);

if(BSP_QSPI_Init()!=HAL_OK)
	Error_Handler();

if(BSP_QSPI_Erase_Chip()!=HAL_OK)
	Error_Handler();

//if(BSP_QSPI_Write(qspi_word, 0, strlen(qspi_word))!=HAL_OK)
//	Error_Handler();
if(BSP_QSPI_Write(qspi_buff, 0, strlen(qspi_buff))!=HAL_OK)
	Error_Handler();


if(BSP_QSPI_Read(qspi_read, 0, 50)!=HAL_OK)
	Error_Handler();

  HAL_Delay(1000);

  while (1)
  {
	  remainingDelay = 300;
	//Pomiary z czujnikow odleglosci
    /* #define logic0_Pin GPIO_PIN_0
 	 * #define logic0_GPIO_Port GPIOH
	 * #define logic1_Pin GPIO_PIN_1
	 * #define logic1_GPIO_Port GPIOH
	 *
 	 * czujnik 1 = logic0 == 0 && logic1 == 0
  	 * czujnik 2 = logic0 == 1 && logic1 == 0
 	 * czujnik 3 = logic0 == 0 && logic1 == 1
 	 * czujnik 4 = logic0 == 1 && logic1 == 1
  	 */

  	HAL_GPIO_WritePin(GPIOH, logic0_Pin, GPIO_PIN_RESET);
  	HAL_GPIO_WritePin(GPIOH, logic1_Pin, GPIO_PIN_RESET);
  	HAL_Delay(50);
  	start = HAL_TIM_ReadCapturedValue(&htim2, TIM_CHANNEL_1);
  	stop = HAL_TIM_ReadCapturedValue(&htim2, TIM_CHANNEL_2);
  	distance1 = (stop - start) / 58.0f;
  	HAL_Delay(50);

  	HAL_GPIO_WritePin(GPIOH, logic0_Pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOH, logic1_Pin, GPIO_PIN_RESET);
	HAL_Delay(50);
	start = HAL_TIM_ReadCapturedValue(&htim2, TIM_CHANNEL_1);
   	stop = HAL_TIM_ReadCapturedValue(&htim2, TIM_CHANNEL_2);
	distance2 = (stop - start) / 58.0f;
	HAL_Delay(50);

	HAL_GPIO_WritePin(GPIOH, logic0_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOH, logic1_Pin, GPIO_PIN_SET);
	HAL_Delay(50);
	start = HAL_TIM_ReadCapturedValue(&htim2, TIM_CHANNEL_1);
	stop = HAL_TIM_ReadCapturedValue(&htim2, TIM_CHANNEL_2);
	distance3 = (stop - start) / 58.0f;
	HAL_Delay(50);

	HAL_GPIO_WritePin(GPIOH, logic0_Pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOH, logic1_Pin, GPIO_PIN_SET);
	HAL_Delay(50);
	start = HAL_TIM_ReadCapturedValue(&htim2, TIM_CHANNEL_1);
	stop = HAL_TIM_ReadCapturedValue(&htim2, TIM_CHANNEL_2);
	distance4 = (stop - start) / 58.0f;
	HAL_Delay(50);


	//printf("\r\n");
	printf("Dist: %.3f %.3f %.3f %.3f \r\n", distance1, distance2, distance3, distance4); //cm

	// docelowo taka funkcja
	//Buzzer
	/*if(distanceMin < 200)
	  {
	  	for(int i = 0; i < (200 - distanceMin)/40; i++)
	 	{
	  		HAL_GPIO_TogglePin(Buzzer_GPIO_Port, Buzzer_Pin);
	  		HAL_Delay(1);
	  		remainingDelay -= 1;
	  	}
	  }*/

	 // to do usunięcia potem
	distanceMin = min(min(distance1,distance2),min(distance3,distance4));
	if(distanceMin <= 15)
	{
	    HAL_GPIO_TogglePin(Buzzer_GPIO_Port, Buzzer_Pin);
	    HAL_Delay(1);
	    HAL_GPIO_TogglePin(Buzzer_GPIO_Port, Buzzer_Pin);
	    HAL_Delay(1);
	    HAL_GPIO_TogglePin(Buzzer_GPIO_Port, Buzzer_Pin);
	    HAL_Delay(1);
	    remainingDelay -= 3;
	}

	if(distanceMin <= 50 && distanceMin >15)
	{
	    HAL_GPIO_TogglePin(Buzzer_GPIO_Port, Buzzer_Pin);
	    HAL_Delay(3);
	    HAL_GPIO_TogglePin(Buzzer_GPIO_Port, Buzzer_Pin);
	    HAL_Delay(3);
	    remainingDelay -= 2;
	 }

	if(distanceMin <= 100 && distanceMin > 50)
	{
	    HAL_GPIO_TogglePin(Buzzer_GPIO_Port, Buzzer_Pin);
	    HAL_Delay(3);
	    remainingDelay -= 1;
	}

  	//Akcelerometr
	LSM303C_AccReadXYZ(acc_data);
	acc[0] = ((acc_data[0] >> 4)*9.81)/1000;	//m/s2
	acc[1] = ((acc_data[1] >> 4)*9.81)/1000;	//m/s2
	acc[2] = ((acc_data[2] >> 4)*9.81)/1000;	//m/s2
	printf("ACC: %.3f %.3f %.3f \r\n", acc[0], acc[1], acc[2]);


	//Gyro
  	BSP_GYRO_GetXYZ(gyro_data);
  	gyro[0] = gyro_data[0]/1000;//-gyro[0];
	gyro[1] = gyro_data[1]/1000;//-gyro[1];
	gyro[2] = gyro_data[2]/1000;//-gyro[2];
	printf("GYRO: %.3f %.3f %.3f \r\n", gyro[0], gyro[1], gyro[2]);


  	//RTC
  	HAL_RTC_GetTime(&hrtc, &sTime, RTC_FORMAT_BIN);
  	HAL_RTC_GetDate(&hrtc, &sDate, RTC_FORMAT_BIN);

  	/* Display time Format: hh:mm:ss */
  	//printf("CZAS: %02d:%02d:%02d \r\n",sTime.Hours, sTime.Minutes, sTime.Seconds);
  	/* Display date Format: dd-mm-yy */
  	//printf("DATA: %02d-%02d-%2d \r\n",sDate.Date, sDate.Month, 2000 + sDate.Year);

  	printf("\r\n");


  	//paczka X, czunik, ACC_X, ACC_Y, GYRO_X, GYRO_Y
  	printf("X %.3f %.3f %.3f %.3f %.3f \r\n", distance1, acc[0], acc[1], gyro[0], gyro[1]); //Crc16


  	//przerwa
  	HAL_Delay(500);

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_LSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 10;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief QUADSPI Initialization Function
  * @param None
  * @retval None
  */
static void MX_QUADSPI_Init(void)
{

  /* USER CODE BEGIN QUADSPI_Init 0 */

  /* USER CODE END QUADSPI_Init 0 */

  /* USER CODE BEGIN QUADSPI_Init 1 */

  /* USER CODE END QUADSPI_Init 1 */
  /* QUADSPI parameter configuration*/
  hqspi.Instance = QUADSPI;
  hqspi.Init.ClockPrescaler = 1;
  hqspi.Init.FifoThreshold = 4;
  hqspi.Init.SampleShifting = QSPI_SAMPLE_SHIFTING_HALFCYCLE;
  hqspi.Init.FlashSize = 23;
  hqspi.Init.ChipSelectHighTime = QSPI_CS_HIGH_TIME_6_CYCLE;
  hqspi.Init.ClockMode = QSPI_CLOCK_MODE_0;
  if (HAL_QSPI_Init(&hqspi) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN QUADSPI_Init 2 */

  /* USER CODE END QUADSPI_Init 2 */

}

/**
  * @brief RTC Initialization Function
  * @param None
  * @retval None
  */
static void MX_RTC_Init(void)
{

  /* USER CODE BEGIN RTC_Init 0 */

  /* USER CODE END RTC_Init 0 */

  RTC_TimeTypeDef sTime = {0};
  RTC_DateTypeDef sDate = {0};

  /* USER CODE BEGIN RTC_Init 1 */

  /* USER CODE END RTC_Init 1 */

  /** Initialize RTC Only
  */
  hrtc.Instance = RTC;
  hrtc.Init.HourFormat = RTC_HOURFORMAT_24;
  hrtc.Init.AsynchPrediv = 127;
  hrtc.Init.SynchPrediv = 255;
  hrtc.Init.OutPut = RTC_OUTPUT_DISABLE;
  hrtc.Init.OutPutRemap = RTC_OUTPUT_REMAP_NONE;
  hrtc.Init.OutPutPolarity = RTC_OUTPUT_POLARITY_HIGH;
  hrtc.Init.OutPutType = RTC_OUTPUT_TYPE_OPENDRAIN;
  if (HAL_RTC_Init(&hrtc) != HAL_OK)
  {
    Error_Handler();
  }

  /* USER CODE BEGIN Check_RTC_BKUP */
  HAL_RTC_GetTime(&hrtc, &sTime, RTC_FORMAT_BIN);
  HAL_RTC_GetDate(&hrtc, &sDate, RTC_FORMAT_BIN);
  return;
  /* USER CODE END Check_RTC_BKUP */

  /** Initialize RTC and set the Time and Date
  */
  sTime.Hours = 16;
  sTime.Minutes = 17;
  sTime.Seconds = 0;
  sTime.DayLightSaving = RTC_DAYLIGHTSAVING_NONE;
  sTime.StoreOperation = RTC_STOREOPERATION_RESET;
  if (HAL_RTC_SetTime(&hrtc, &sTime, RTC_FORMAT_BIN) != HAL_OK)
  {
    Error_Handler();
  }
  sDate.WeekDay = RTC_WEEKDAY_TUESDAY;
  sDate.Month = RTC_MONTH_MAY;
  sDate.Date = 10;
  sDate.Year = 22;

  if (HAL_RTC_SetDate(&hrtc, &sDate, RTC_FORMAT_BIN) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN RTC_Init 2 */

  /* USER CODE END RTC_Init 2 */

}

/**
  * @brief SPI2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI2_Init(void)
{

  /* USER CODE BEGIN SPI2_Init 0 */

  /* USER CODE END SPI2_Init 0 */

  /* USER CODE BEGIN SPI2_Init 1 */

  /* USER CODE END SPI2_Init 1 */
  /* SPI2 parameter configuration*/
  hspi2.Instance = SPI2;
  hspi2.Init.Mode = SPI_MODE_MASTER;
  hspi2.Init.Direction = SPI_DIRECTION_1LINE;
  hspi2.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi2.Init.CLKPolarity = SPI_POLARITY_HIGH;
  hspi2.Init.CLKPhase = SPI_PHASE_2EDGE;
  hspi2.Init.NSS = SPI_NSS_SOFT;
  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;
  hspi2.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi2.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi2.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi2.Init.CRCPolynomial = 7;
  hspi2.Init.CRCLength = SPI_CRC_LENGTH_DATASIZE;
  hspi2.Init.NSSPMode = SPI_NSS_PULSE_DISABLE;
  if (HAL_SPI_Init(&hspi2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI2_Init 2 */

  /* USER CODE END SPI2_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_IC_InitTypeDef sConfigIC = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 79;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 999999;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_IC_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
  sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
  sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
  sConfigIC.ICFilter = 0;
  if (HAL_TIM_IC_ConfigChannel(&htim2, &sConfigIC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_FALLING;
  sConfigIC.ICSelection = TIM_ICSELECTION_INDIRECTTI;
  if (HAL_TIM_IC_ConfigChannel(&htim2, &sConfigIC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 10;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */
  HAL_TIM_MspPostInit(&htim2);

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOH, logic0_Pin|logic1_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, Buzzer_Pin|GYRO_CS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(XL_CS_GPIO_Port, XL_CS_Pin, GPIO_PIN_SET);

  /*Configure GPIO pins : logic0_Pin logic1_Pin */
  GPIO_InitStruct.Pin = logic0_Pin|logic1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOH, &GPIO_InitStruct);

  /*Configure GPIO pins : MAG_INT_Pin MAG_DRDY_Pin */
  GPIO_InitStruct.Pin = MAG_INT_Pin|MAG_DRDY_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : Buzzer_Pin */
  GPIO_InitStruct.Pin = Buzzer_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(Buzzer_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : GYRO_INT1_Pin */
  GPIO_InitStruct.Pin = GYRO_INT1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GYRO_INT1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : GYRO_CS_Pin */
  GPIO_InitStruct.Pin = GYRO_CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(GYRO_CS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : GYRO_INT2_Pin */
  GPIO_InitStruct.Pin = GYRO_INT2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GYRO_INT2_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : XL_CS_Pin */
  GPIO_InitStruct.Pin = XL_CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(XL_CS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : XL_INT_Pin */
  GPIO_InitStruct.Pin = XL_INT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(XL_INT_GPIO_Port, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
